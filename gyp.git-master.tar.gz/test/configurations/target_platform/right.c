const char *message(void) {
  return "right";
}
